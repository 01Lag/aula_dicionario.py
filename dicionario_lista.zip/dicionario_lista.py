contatos={
    'João':'(12)992342167',
    'Guilherme':'(12)992453789',
    'Laís': '(12)991897754',
    'Pedro': '(11)998132906',
    'Monica': '(11)9982342787'
}
print('Seja Bem-vindo ao gerenciador de Contatos!')

while True:
    print('\nEscolha uma opção:')
    print('1. Mostrar todos os contatos')
    print('2. Adicionar um novo contato')
    print('3. Buscar número de telefone através do nome')
    print('4. Remover contato')
    print('5. Sair')

    escolha= input('Digite o número da opação desejada:')

    if escolha == '1':
        print('\nContatos:')
        for nome, telefone in contatos.items():
            print(f'{nome}:{telefone}')
    elif escolha == '2':
        nome_novo_contato = input('Digite o nome do novo contato:')
        telefone_novo_contato = input('Digite o numero de telefone:')
        contatos[nome_novo_contato] = telefone_novo_contato
        print(f'Contato {nome_novo_contato}adicionado com sucesso!')

    elif escolha == '3':
        nome_busca = input('Digite o nome do contato para buscar o número de  telefone:')
        if nome_busca in contatos:
            print(f'O número de telefone de {nome_busca} contatos é: {contatos[nome_busca]}')
        else: 
            print('Contato não encontrado.')

    elif escolha == '4':
        nome_remover = input('Digite o nome do contato para remover:')
        if nome_remover in contatos:
            print(f'Contato {nome_remover} removido com sucesso!')
        else:
            print('Contato não encontrado.')

    elif escolha == '5':
        print('Saindo. Até a próxima!')
        break
    else:
        print('Opção inválida. Tente novamente!')
        